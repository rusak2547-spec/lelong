import { drizzle } from 'drizzle-orm/better-sqlite3';
import Database from 'better-sqlite3';
import * as schema from './schema';
import { join, dirname } from 'path';
import { fileURLToPath } from 'url';

// Get the directory of this file (works in both dev and production)
const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);

// Database file path - always relative to project root
// In production: uses .env DATABASE_URL (e.g., "file:./lelong.db")
// In development: defaults to dev.db in project root
const getDbPath = () => {
  const envPath = process.env.DATABASE_URL?.replace('file:', '').replace('./', '');
  if (envPath) {
    // If path starts with /, it's absolute - use as is
    if (envPath.startsWith('/')) return envPath;
    // Otherwise, make it relative to project root (one level up from lib/)
    return join(__dirname, '..', envPath);
  }
  // Default: dev.db in project root
  return join(__dirname, '..', 'dev.db');
};

const dbPath = getDbPath();

// Create SQLite database connection
const sqlite = new Database(dbPath);

// Create Drizzle instance with schema
const db = drizzle(sqlite, { schema });

export default db;

// Export schema for convenience
export { schema };
